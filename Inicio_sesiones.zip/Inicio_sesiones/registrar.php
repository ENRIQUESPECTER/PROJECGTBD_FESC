<!DOCTYPE html>
<html>
<head>
	<title>REGISTRO</title>
</head>
<meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>INICIO DE SESION/REGISTRO_USUARIO</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <body id="page-top">
	 <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
            <div class="container px-4 px-lg-5">
                 <a class="navbar-brand" href="registro.php">Regresar</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    HOLA
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
                <div class="d-flex justify-content-center">
                    <div class="text-center"> 
                        </br>
                    </br>
                        <div align="center" >
<?php
$server="localhost";
$usuario="root";
$contrasena="";
$bd="pfsesiones";

$conexion = mysqli_connect($server,$usuario,$contrasena,$bd)
or die("Error en la conexión");

$usuario = $_POST['txtUsuario'];
$password=$_POST['password'];
$correo=$_POST['txtCorreo'];
$telefono=$_POST['Telefono'];
$domicilio=$_POST['txtDomicilio'];
$insertar= "INSERT into registros values ('$usuario','$password','$correo','$telefono','$domicilio')";
$resultado = mysqli_query($conexion,$insertar)
or die("Error al insertar los regisros");
mysqli_close($conexion);
echo "Datos insertados correctamente";
?>
<form action="index.html" method="POST">
	<input class="btn btn-primary" type="submit" value="Página principal" name="btnVolver">
</form>
</body>
</html>