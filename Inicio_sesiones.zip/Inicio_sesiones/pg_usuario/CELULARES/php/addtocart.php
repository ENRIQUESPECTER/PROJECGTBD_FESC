<?php

session_start();
if(!empty($_POST)){
	if(isset($_POST["id_producto"]) && isset($_POST["q"])){
		// si es el primer producto simplemente lo agregamos
		if(empty($_SESSION["carro"])){
			$_SESSION["carro"]=array( array("id_producto"=>$_POST["id_producto"],"q"=> $_POST["q"]));
		}else{
			// apartie del segundo producto:
			$carro = $_SESSION["carro"];
			$repeated = false;
			// recorremos el carrito en busqueda de producto repetido
			foreach ($carro as $c) {
				// si el producto esta repetido rompemos el ciclo
				if($c["id_producto"]==$_POST["id_producto"]){
					$repeated=true;
					break;
				}
			}
			// si el producto es repetido no hacemos nada, simplemente redirigimos
			if($repeated){
				print "<script>alert('Error: Producto Repetido!');</script>";
			}else{
				// si el producto no esta repetido entonces lo agregamos a la variable cart y despues asignamos la variable cart a la variable de sesion
				array_push($carro, array("id_producto"=>$_POST["id_producto"],"q"=> $_POST["q"]));
				$_SESSION["carro"] = $carro;
			}
		}
		print "<script>window.location='../productschh.php'</script>";
	}
}

?>

