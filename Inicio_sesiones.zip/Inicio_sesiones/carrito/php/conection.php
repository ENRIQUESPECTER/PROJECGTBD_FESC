<?php

$con  = new mysqli("localhost","root","","proyecto3p");

?>