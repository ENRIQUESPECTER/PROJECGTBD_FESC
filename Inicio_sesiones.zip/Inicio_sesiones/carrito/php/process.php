<?php 
session_start();
include "conection.php";
if(!empty($_POST)){
$q1 = $con->query("insert into cart(email_cliente,crear) value(\"$_POST[email]\",NOW())");
if($q1){
$id_carro = $con->insert_id;
foreach($_SESSION["carro"] as $c){
$q1 = $con->query("insert into carro_producto(id_producto,q,id_carro) value($c[id_producto],$c[q],$id_carro)");
}
unset($_SESSION["carro"]);
}
}
print "<script>alert('Venta procesada exitosamente');window.location='../carropro.php';</script>";
?>