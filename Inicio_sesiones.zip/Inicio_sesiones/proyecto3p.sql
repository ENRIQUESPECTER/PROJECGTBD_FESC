-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-12-2021 a las 20:49:15
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto3p`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carro`
--

CREATE TABLE `carro` (
  `id` int(11) NOT NULL,
  `email_cliente` varchar(50) DEFAULT NULL,
  `crear` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carro_producto`
--

CREATE TABLE `carro_producto` (
  `id` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_carro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `precio` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `nombre`, `precio`) VALUES
(1, 'Computadora LENOVO L560 CORE I5 8gb de Ram', 10800),
(2, 'Computadora DELL INSPIRON 8GB de Ram', 14000),
(3, 'Computadora ACER NITRO 8GB de RAM', 25000),
(4, 'Computadora HP 15t 16GB de Ram', 10899),
(5, 'Computadora APPLE iMac 8GB Ram', 33500),
(6, 'SAMSUNG Galaxy-A03s 4GB_64GB', 4200),
(7, 'MOTO G60 128+6GB Dual SIM', 6000),
(8, 'HUAWEI Nova 8i 6GB Ram + 128 GB Rom', 7500),
(9, 'ZTE Smartphone Blade A71 64GB ', 3750),
(10, 'Xiaomi Redmi 10 Carbon Gray 4Gb Ram', 5915),
(11, 'TCL Television 32\" HD LED 720p Android', 5000),
(12, 'VIZIO Smart TV 40\" Serie D Full HD 1080p', 5799),
(13, 'Hisense 32 pul 720p Televisor HD Pantalla LED TV', 4589),
(14, 'Pantalla Samsung 58\" Crystal UHD 4K', 12500),
(15, 'Pantalla LG 55\" 4K Smart TV LED', 9999),
(16, 'HUAWEI Matepad T 10s - Tablet 10.1\"', 3599),
(17, 'Lenovo Smart Tab M10 Plus, Tablet Android', 6800),
(18, 'TECLAST Tablet Android 8 pulgadas 1.6GHz', 2110),
(19, 'Hyjoy Tablet 9 Pulgadas 2GB RAM 32GB ROM', 2400),
(20, 'AEEZO Tableta 10.1 Pulgadas Android 10', 2500),
(21, 'Consola Playstation 4 - Megapack 18', 8500),
(22, 'Consola PlayStation 5 - Digital Edition', 11000),
(23, 'Consola Xbox ONE HALO 5  Edition', 6000),
(24, 'Consola Xbox Series S', 8000),
(25, 'Nintendo Consola Switch Neon 32GB ', 6700);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carro`
--
ALTER TABLE `carro`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `carro_producto`
--
ALTER TABLE `carro_producto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carro`
--
ALTER TABLE `carro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `carro_producto`
--
ALTER TABLE `carro_producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
